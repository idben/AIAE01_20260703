# 🔎 排隊隊伍！用 index() 找出某個人排在第幾個（索引從 0 算）
queue = ["小明", "小華", "小美", "阿強"]

# TODO：用 index() 找出 "小美" 在 queue 的位置，存進 pos
pos = None
