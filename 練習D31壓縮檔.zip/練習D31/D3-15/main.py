# 📄 收到一筆逗號分隔的資料，用 split() 把它「拆成清單」
data = "蘋果,香蕉,橘子,西瓜"

# TODO：用 split() 把 data 依「逗號」拆成清單，存進 fruits
fruits = None
