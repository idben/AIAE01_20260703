# 🔡 拆解密碼！用 list() 可以把一個字串「拆成一個一個字元」的清單
password = "A1B2C3"

# TODO：用 list() 把 password 拆成字元清單，存進 chars
#       例如 list("AB") 會得到 ['A', 'B']
chars = None
