# D3-19 練習：找第一個不及格（enumerate + break）

## 題目

分數清單 `scores = [80, 55, 90, 40]`。
用 `enumerate` 同時取索引與分數，找出「第一個」不及格（`< 60`）的索引存進 `fail_index`，找到就 `break`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for i, s in enumerate(scores)` 可同時拿到索引 `i` 與分數 `s`
- 找到第一個就 `break`，才不會被後面的覆蓋

## 這題常見錯誤

- 沒有 `break`，`fail_index` 會被後面的不及格值覆蓋掉
- 忘了 `enumerate` 會回傳「索引, 值」兩個

## 這題在測什麼

- 是否會用 `enumerate` 搭配 `break` 找第一個符合的索引
