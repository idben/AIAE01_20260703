# 🥇 頒獎典禮！用「解包」把冠軍單獨拿出來，其他名次用 * 收集成一個清單
results = ["金牌", "銀牌", "銅牌", "第四名"]

# TODO：用「解包」（搭配 *）把第一名給 champion、其餘用 * 收集給 others
#       champion 應拿到 "金牌"，others 應拿到 ["銀牌", "銅牌", "第四名"]
champion = None
others = None
