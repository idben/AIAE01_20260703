# 🎁 抽獎！用 pop() 抽走清單「最後一張」獎券
# 特別的是：pop() 會「回傳」被抽走的那個值
box = [10, 20, 30]

# TODO：用 pop() 抽走 box 最後一個，把抽中的號碼存進 prize
#       抽完 prize 應是 30、box 應剩 [10, 20]
prize = None
