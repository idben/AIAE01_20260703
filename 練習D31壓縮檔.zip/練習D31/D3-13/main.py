# 📅 把上午與下午的行程「合併」成一天的完整行程（用 +）
morning = ["晨會", "巡檢"]
afternoon = ["寫報告", "開會"]

# TODO：用 + 把 morning 和 afternoon 接成一個清單，存進 schedule
schedule = None
