# D3-13 練習：整天行程（+ 合併）

## 題目

上午行程 `morning`、下午行程 `afternoon`。
用 `+` 把兩個清單接成一整天的 `schedule`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- 兩個清單用 `+` 就能接成一個新清單
- 順序：`morning + afternoon` 上午在前

## 這題常見錯誤

- 用逗號包起來 `[morning, afternoon]`（那會變成「清單裡放兩個清單」的巢狀清單）

## 這題在測什麼

- 是否會用 `+` 合併兩個清單
