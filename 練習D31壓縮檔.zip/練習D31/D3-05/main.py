# 🙋 活動報名結束，用 len() 數數看總共有幾個人報名
guests = ["小明", "小華", "小美", "阿強", "阿珍"]

# TODO：用 len() 算出 guests 的人數，存進 total
total = None
