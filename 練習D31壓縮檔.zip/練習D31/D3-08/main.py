# 🗳️ 開票囉！用 count() 數數看候選人 "A" 總共得幾票
votes = ["A", "B", "A", "C", "A", "B"]

# TODO：用 count() 算出 "A" 出現幾次，存進 a_count
a_count = None
