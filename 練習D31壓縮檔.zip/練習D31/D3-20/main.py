# 🧮 三組各兩科分數（巢狀 list），把所有分數加起來
matrix = [[1, 2], [3, 4], [5, 6]]
total = 0

# TODO：用巢狀 for 走訪 matrix
#       外層 for row 拿每一組、內層 for x 拿每個分數，全部加進 total
