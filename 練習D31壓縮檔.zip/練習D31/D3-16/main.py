# 🏷️ 把多個標籤用 "-" 串成一個字串，用 join()
tags = ["news", "tech", "ai"]

# TODO：用 join() 以 "-" 為分隔，把 tags 串成一個字串，存進 result
#       結果應該是 "news-tech-ai"
result = None
