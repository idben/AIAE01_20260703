# 🎫 進場檢查！用 in 判斷某個人是不是在 VIP 名單裡（結果是布林值）
vip_list = ["Amy", "Bob", "Cathy"]

# TODO：判斷 "Bob" 是否在 vip_list 裡，把結果（True／False）存進 is_vip
is_vip = None
