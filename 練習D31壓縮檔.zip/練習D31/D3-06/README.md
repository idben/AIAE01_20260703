# D3-06 練習：VIP 進場（in 判斷）

## 題目

VIP 名單 `vip_list = ["Amy", "Bob", "Cathy"]`。
判斷 `"Bob"` 是否在名單裡，結果（布林值）存進 `is_vip`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `"Bob" in vip_list` 的結果本身就是 `True` 或 `False`
- 直接把這個結果存起來即可

## 這題常見錯誤

- 想存數字 `1`／`0`（要存布林值 `True`／`False`）

## 這題在測什麼

- 是否會用 `in` 做成員判斷
