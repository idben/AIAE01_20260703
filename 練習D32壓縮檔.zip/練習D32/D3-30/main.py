# ☕ 用「大括號」建立一筆商品資料（key: value）
# TODO：建立一個字典，key "name" 對應 "咖啡"、key "price" 對應 60，存進 product
product = None
