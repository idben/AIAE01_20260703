# D3-22 練習：借同一份 vs 影印一份（is 判斷）

## 題目

`original = [1, 2, 3]`。`linked` 直接指向同一份；`copied` 用 `list(original)` 影印成新的一份。
用 `is` 判斷 `same1`（linked 與 original 是否同一物件）與 `same2`（copied 與 original 是否同一物件）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `is` 檢查的是「是不是同一個物件」，不是「值一不一樣」
- `list(original)` 會做出一份「新的」清單，所以和原本不是同一個物件

## 這題常見錯誤

- 把 `is`（同一物件）和 `==`（值相等）搞混（兩份內容相同但 `is` 會是 `False`）

## 這題在測什麼

- 是否會用 `is` 判斷兩個變數是否指向同一物件
