# 📄 linked 是「借同一份」，copied 是「影印新的一份」
# original 是原本的清單。用 is 檢查兩個名字是不是指向「同一個物件」
original = [1, 2, 3]

# TODO：
#   1. linked = original（指向同一份）
#   2. copied = list(original)（用 list() 影印成新的一份）
#   3. same1：linked 和 original 是不是「同一個物件」？（用 is）→ 布林
#   4. same2：copied 和 original 是不是「同一個物件」？（用 is）→ 布林
linked = None
copied = None
same1 = None
same2 = None
