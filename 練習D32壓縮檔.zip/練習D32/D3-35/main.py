# 🔐 已註冊帳號名單（key 是帳號）。用 in 檢查某帳號是否存在（布林）
users = {"amy": "1234", "bob": "5678"}

# TODO：
#       has_amy：用 in 判斷 "amy" 是不是已註冊帳號 → 布林
#       has_tom：用 in 判斷 "tom" 是不是已註冊帳號 → 布林
has_amy = None
has_tom = None
