# D3-39 練習：購物車總額（走訪 values 加總）

## 題目

購物車 `prices = {"蘋果": 30, "香蕉": 20, "橘子": 25}`。
用 `for` 走訪 `.values()` 把所有價格加進 `total`（總額 `75`）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for price in prices.values()` 會一個個拿到「值」
- 若直接 `for x in prices` 拿到的是 key（商品名），不是價格

## 這題常見錯誤

- 直接走訪字典拿到 key，卻拿去相加（會出錯或算錯）

## 這題在測什麼

- 是否會用 `.values()` 走訪字典的值
