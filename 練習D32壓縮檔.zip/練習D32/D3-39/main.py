# 🧮 購物車（商品: 價格），把所有價格加起來算總額
# 走訪字典的「值」用 .values()
prices = {"蘋果": 30, "香蕉": 20, "橘子": 25}
total = 0

# TODO：用 for 走訪 prices.values()，把每個價格加進 total
