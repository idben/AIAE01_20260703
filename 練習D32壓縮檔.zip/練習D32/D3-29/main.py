# 🥇 一場比賽的分數（由高到低，存成 tuple）
# 用「星號解包」把第一名單獨拿出來，其餘用 * 收集成一個清單
scores = (95, 88, 76, 60)

# TODO：用「星號解包」把第一名給 first、其餘用 * 收集給 rest
#       first 應拿到 95，rest 應拿到 [88, 76, 60]（注意：星號收集後會是 list）
first = None
rest = None
