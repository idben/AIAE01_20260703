# 📦 倉庫庫存表。用 get() 查詢比較安全：查不到的 key 不會報錯，還可給預設值
stock = {"筆": 10, "橡皮擦": 5}

# TODO：
#       pen：用 get() 查「筆」的庫存 → 10
#       ruler：用 get() 查「尺」的庫存，查不到就給預設 0 → 0
pen = None
ruler = None
