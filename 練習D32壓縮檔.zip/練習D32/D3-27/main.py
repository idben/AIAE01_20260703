# 📍 一個座標點 (x, y) 存成 tuple，用「解包」把 x 和 y 分別拿出來
point = (3, 5)

# TODO：用「解包」把 point 的兩個值分別放進 x 和 y（x 應是 3、y 應是 5）
x = None
y = None
