# 🗑️ 購物車字典（商品: 價格）
# del 依 key 刪除；pop(key) 會刪除「並回傳」被刪掉的值
cart = {"蘋果": 30, "香蕉": 20, "橘子": 25}

# TODO：
#   1. 用 del 把 "香蕉" 從 cart 刪掉
#   2. 用 pop("蘋果") 把蘋果刪掉，並把它的價格存進 removed_price
#   最後 removed_price 應是 30、cart 應剩 {"橘子": 25}
removed_price = None
