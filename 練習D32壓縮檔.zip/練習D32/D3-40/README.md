# D3-40 練習：找高分科目（走訪 items 收集）

## 題目

成績 `scores = {"國文": 80, "英文": 95, "數學": 70}`。
用 `.items()` 同時拿科目與分數，把分數 `>= 90` 的科目名收進 `top_subjects`（結果 `["英文"]`）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `for name, score in scores.items()` 會一次拿到 key 與 value
- 條件符合就用 `append()` 把「科目名（key）」加進清單

## 這題常見錯誤

- 收集時加到的是分數而不是科目名
- 忘了 `.items()` 會一次給「key, value」兩個

## 這題在測什麼

- 是否會用 `.items()` 同時走訪 key 與 value
