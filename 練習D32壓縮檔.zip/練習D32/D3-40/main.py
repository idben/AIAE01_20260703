# 🏅 各科成績（科目: 分數）。找出「90 分以上」的科目名稱
# 走訪字典同時拿 key 與 value 用 .items()
scores = {"國文": 80, "英文": 95, "數學": 70}
top_subjects = []

# TODO：用 .items() 走訪 scores（可同時拿到科目與分數）
#       分數 >= 90 的科目，用 append() 把「科目名」加進 top_subjects
#       結果應是 ["英文"]
