# 🎰 本期樂透中獎號碼（存成 tuple）
winning = (3, 7, 12, 25, 38)

# TODO：
#       total：用 len() 算出總共有幾個號碼
#       has_7：用 in 判斷 7 是不是中獎號碼（布林）
total = None
has_7 = None
