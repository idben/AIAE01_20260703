# D3-21 練習：共用購物清單（參考指向）

## 題目

你和室友共用一份購物清單：`shared = ["蛋", "奶"]`，且 `roommate = shared`。
你用 `append` 把 `"麵包"` 加進 `shared` 之後，判斷 `roommate` 有沒有「跟著」變，把答案（布林）存進 `roommate_changed`。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `roommate = shared` 只是讓兩個名字指向「同一份」清單，不是複製
- 改了其中一個，另一個會跟著變，所以答案是 `True`

## 這題常見錯誤

- 以為 `roommate` 是獨立的另一份（清單不像數字，指派只是共用同一份）
- `roommate_changed` 要存布林值，不是文字

## 這題在測什麼

- 是否理解「清單指派是共用同一個物件」的參考指向行為
