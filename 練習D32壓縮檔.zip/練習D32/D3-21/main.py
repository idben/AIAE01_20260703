# 🧺 你和室友「共用」同一份購物清單（roommate = shared 讓兩個名字指向同一份）
# 想想看：你改了清單，室友看到的會不會跟著變？
shared = ["蛋", "奶"]
roommate = shared

# TODO：
#   1. 用 append() 把 "麵包" 加進 shared
#   2. roommate 有沒有「跟著」多出麵包？把答案存進 roommate_changed（True 或 False）
roommate_changed = None
