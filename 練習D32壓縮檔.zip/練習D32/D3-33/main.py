# 🍎 水果價目表，用 [] 查出某個水果的價格
prices = {"蘋果": 30, "香蕉": 20, "橘子": 25}

# TODO：用 [] 依 key 取出「蘋果」的價格，存進 apple_price
apple_price = None
