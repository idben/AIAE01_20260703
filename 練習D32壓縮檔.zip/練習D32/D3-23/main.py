# 🪪 用 tuple 把一筆學生資料「打包」起來：姓名、年齡、分數
# tuple 用小括號建立，可以混合不同型別
# TODO：建立一個 tuple，依序放入 "小明"、18、90，存進 student
student = None
