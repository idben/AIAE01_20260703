# 🧑 用 dict() 建構子建立字典：dict(鍵=值) 這種寫法，鍵不用加引號
# TODO：用 dict() 建構子建立字典，讓 name 對應 "小明"、age 對應 18，存進 person
person = None
