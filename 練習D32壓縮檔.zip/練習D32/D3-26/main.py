# 📊 一串感測讀數（存成 tuple）
data = (1, 2, 2, 3, 2, 4)

# TODO：
#       twos：用 count() 算出 2 出現幾次
#       first_three：用 index() 找出 3 第一次出現的位置（索引從 0 算）
twos = None
first_three = None
