# D3-26 練習：感測讀數（count 與 index）

## 題目

感測讀數 `data = (1, 2, 2, 3, 2, 4)`。
用 `count()` 算出 `2` 出現幾次（`twos`）；用 `index()` 找出 `3` 第一次出現的位置（`first_three`，索引從 0 算）。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `data.count(2)` 回傳出現次數
- `data.index(3)` 回傳第一次出現的索引

## 這題常見錯誤

- 把「出現次數」和「索引位置」搞混
- 以為 index 從 1 開始算（其實從 0）

## 這題在測什麼

- 是否會對 tuple 使用 `count()` 與 `index()`
