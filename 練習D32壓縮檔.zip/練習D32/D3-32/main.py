# 📝 把「科目」與「分數」兩個清單組成一份成績單字典（提示：zip 搭配 dict）
subjects = ["國文", "英文", "數學"]
points = [80, 90, 70]

# TODO：用 zip() 把 subjects 與 points 配對，再用 dict() 組成字典，存進 report
#       結果應是 {"國文": 80, "英文": 90, "數學": 70}
report = None
